<?php


include_once 'DAO_Usuarios.php';
include_once 'DB_Conection.php';

class ModificarDatos extends DB
{
    public function EditarPerfil()
    {
        // Inicio de sesion
        $email = $_POST['correo'];
        $nombre = $_POST['nombre'];
        $telefono = $_POST['telefono'];
        $password = $_POST['passw'];
        $fechaNacimiento = $_POST['fechaNacimiento'];
        $direccion = $_POST['direccion'];
        $idSexo = $_POST['sexo'];
        $idUsuario = $_POST['idUsuario'];
        
        $fechaNacimientoMySQL = DateTime::createFromFormat('d/m/Y', $fechaNacimiento)->format('Y-m-d');

          // Obtiene la cadena de la imagen desde el cuerpo del POST
          $base64ImageString = $_POST['imagen'];

          // Elimina el prefijo "data:image/png;base64," si está presente
          $base64ImageString = str_replace('data:image/png;base64,', '', $base64ImageString);
          $base64ImageString = str_replace(' ', '+', $base64ImageString);
  
          // Decodifica la cadena base64 a bytes
          $imgContenido = base64_decode($base64ImageString);


        $modifyUser = new Usuarios();

        $db = new DB();
        $pdo = $db->connect();
        if ($pdo) {
            try {
                $result = $modifyUser->ModificarUsuario($pdo, $idUsuario, $idSexo, $email, $password, $nombre, $telefono, $fechaNacimientoMySQL, $direccion, $imgContenido);

                if ($result) {
                    return $result;
                }
                else{
                    return $result;
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        }
    }

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ModificacionDatos = new ModificarDatos();
    $result = $ModificacionDatos->EditarPerfil();
    if ($result === true) {
        $res2['resultado'] = "true";
        echo json_encode($res2);
    } else {
        echo $result;
    }
}

?>