<?php

include_once 'DAO_Doctores.php';
include_once 'DB_Conection.php';

class EliminarDoctor extends DB
{
    public function _EliminarDoctor()
    {
        // Inicio de sesion
       
        $idDoctor = $_POST['idDoctor'];

        $modificacion = new Doctores();

        $db = new DB();
        $pdo = $db->connect();
        if ($pdo) {
            try {
                $result = $modificacion->EliminarDoctor($pdo, $idDoctor);

                if ($result) {
                    return $result;
                }
                else {
                    return $result;
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        }
    }

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $BajaDoctores = new EliminarDoctor();
    $result = $BajaDoctores->_EliminarDoctor();
    if ($result === true) {
        $res2['resultado'] = "true";
        echo json_encode($res2);
    } else {
        echo $result;
    }
}

?>