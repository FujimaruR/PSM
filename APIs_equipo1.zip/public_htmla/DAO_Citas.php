<?php


include 'DB_Conection.php';

class Citas extends DB
{
   
    public function RegistroCita($pdo, $hora, $idMascota, $idUsuario, $idDoctor, $activo, $fecha)
    {
        try {
            $sql = "INSERT INTO tb_Citas (Hora, idMascota, idUsuario, idDoctor, activo, fecha) 
                    VALUES (:hora, :idMascota, :idUsuario, :idDoctor, :activo, :fecha)";
            $stmt = $pdo->prepare($sql);

          
            $stmt->bindParam(':hora', $hora, PDO::PARAM_STR);
            $stmt->bindParam(':idMascota', $idMascota, PDO::PARAM_INT);
            $stmt->bindParam(':idUsuario', $idUsuario, PDO::PARAM_INT);
            $stmt->bindParam(':idDoctor', $idDoctor, PDO::PARAM_INT);
            $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);
            $stmt->bindParam(':fecha', $fecha, PDO::PARAM_STR);
        
    
            $pdo = null;
            
            if($stmt->execute()){
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    public function ObtenerCitas($pdo, $idUser)
    {
        try {
            $sql = "SELECT 
                        C.idCita AS 'IdCita',
                        C.fecha AS 'FechaCita',
                        C.Hora AS 'HoraCita',
                        M.nombre AS 'NombreMascota',
                        M.raza AS 'RazaMascota',
                        D.nombre AS 'NombreDoctor'
                    FROM 
                        tb_Citas C
                    JOIN 
                        tb_Mascotas M ON C.idMascota = M.idMascota
                    JOIN 
                        tb_Doctores D ON C.idDoctor = D.idDoctor
                    JOIN 
                        tb_Usuario U ON C.idUsuario = U.idUsuario
                    WHERE 
                        U.idUsuario = :idUser AND
                        C.activo = 1 AND
                        C.fecha >= CURDATE()
                    ORDER BY 
                        C.fecha ASC, 
                        C.Hora ASC";
    
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':idUser', $idUser, PDO::PARAM_INT);
            $stmt->execute();
    
            $citas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
            if ($citas) {
                return $citas;
            } else {
                // Podrías cambiar esto para retornar un arreglo vacío o manejar el "no encontrados" de otra manera
                echo "No se encontraron citas.";
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }

    public function EliminarCita($pdo, $idCita)
    {
        try {
            $sql = "UPDATE tb_Citas SET activo = 0 WHERE idCita = :idCita";
            $stmt = $pdo->prepare($sql);
    
            $stmt->bindParam(':idCita', $idCita, PDO::PARAM_INT);
    
            $result = $stmt->execute();
    
            $pdo = null;
    
            if ($result) {
                return true; // Los datos del usuario se modificaron correctamente
            } else {
                return false; // No se pudieron modificar los datos del usuario
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }


}

?>