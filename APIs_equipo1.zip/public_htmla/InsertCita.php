<?php

include_once 'DAO_Citas.php';
include_once 'DB_Conection.php';

class RegistroCita extends DB
{
    public function _RegistroCita()
    {
        // Inicio de sesion
        $hora = $_POST['hora'];
        $idMascota = $_POST['idMascota'];
        $idUsuario = $_POST['idUsuario'];
        $idDoctor = $_POST['idDoctor'];
        $activo = $_POST['activo'];
        $fecha = $_POST['fecha'];
        
        $fechaFormateada = date('Y-m-d', strtotime(str_replace('/', '-', $fecha)));

        $alta = new Citas();

        $db = new DB();
        $pdo = $db->connect();
        if ($pdo) {
            try {
                $result = $alta->RegistroCita($pdo, $hora, $idMascota, $idUsuario, $idDoctor, $activo, $fechaFormateada);

                if ($result) {
                    return $result;
                }
                else {
                    return $result;
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        }
    }

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $AltaCita = new RegistroCita();
    $result = $AltaCita->_RegistroCita();
    if ($result === true) {
        $res2['resultado'] = "true";
        echo json_encode($res2);
    } else {
        echo $result;
    }
}

?>