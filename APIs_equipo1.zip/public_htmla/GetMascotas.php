<?php

header('Content-Type: application/json');


include_once 'DAO_Mascotas.php';

    $Mascota = new Mascotas();
    
    $idUser = $_POST['idUsuario'];
    
    $resd = $Mascota->ObtenMascotas($idUser);
    if ($resd) {
        foreach ($resd as &$fila){
        $base64Image = base64_encode($fila['imagen']);
        
        $fila['imagen'] = $base64Image;
            
        }
        
        echo json_encode($resd);
    } else {
        echo json_encode([]);
    }

?>