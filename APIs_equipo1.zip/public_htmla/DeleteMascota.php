<?php

include_once 'DAO_Mascotas.php';
include_once 'DB_Conection.php';

class DeleteMascota extends DB
{
    public function DeleteMascota()
    {
        // Inicio de sesion
        $idMascota = $_POST['idMascota'];

        // Obtiene la cadena de la imagen desde el cuerpo del POST

        $alta = new Mascotas();

        $db = new DB();
        $pdo = $db->connect();
        if ($pdo) {
            try {
                $result = $alta->DeleteMascota($pdo, $idMascota);

                if ($result) {
                    return $result;
                }
                else {
                    return $result;
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        }
    }

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ModificacionMascota = new DeleteMascota();
    $result = $ModificacionMascota->DeleteMascota();
    if ($result === true) {
        $res2['resultado'] = "true";
        echo json_encode($res2);
    } else {
        echo $result;
    }
}

?>