<?php


include_once 'DAO_Mascotas.php';
include_once 'DB_Conection.php';

    $Mascota = new Mascotas();

    $especie = $_POST['especie'];
    
    $res = $Mascota->InsertEspecie($especie);
    if ($res) {
    echo json_encode(true);
} else {
    echo json_encode(false);
}


?>