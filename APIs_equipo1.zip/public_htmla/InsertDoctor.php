<?php

include_once 'DAO_Doctores.php';
include_once 'DB_Conection.php';

class RegistroDoctor extends DB
{
    public function RegistroDoctor()
    {
        // Inicio de sesion
        $nombre = $_POST['nombre'];
        $activo = $_POST['activo'];

        $alta = new Doctores();

        $db = new DB();
        $pdo = $db->connect();
        if ($pdo) {
            try {
                $result = $alta->Registro($pdo, $nombre, $activo);

                if ($result) {
                    return $result;
                }
                else {
                    return $result;
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        }
    }

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $AltaDoctores = new RegistroDoctor();
    $result = $AltaDoctores->RegistroDoctor();
    if ($result === true) {
        $res2['resultado'] = "true";
        echo json_encode($res2);
    } else {
        echo $result;
    }
}

?>