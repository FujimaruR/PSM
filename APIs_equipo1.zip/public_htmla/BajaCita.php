<?php

include_once 'DAO_Citas.php';
include_once 'DB_Conection.php';

class EliminarCita extends DB
{
    public function _EliminarCita()
    {
        // Inicio de sesion
        $idCita = $_POST['idCita'];

        $baja = new Citas();

        $db = new DB();
        $pdo = $db->connect();
        if ($pdo) {
            try {
                $result = $baja->EliminarCita($pdo, $idCita);

                if ($result) {
                    return $result;
                }
                else {
                    return $result;
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        }
    }

}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bajaCita = new EliminarCita();
    $result = $bajaCita->_EliminarCita();
    if ($result === true) {
        $res2['resultado'] = "true";
        echo json_encode($res2);
    } else {
        echo $result;
    }
}

?>