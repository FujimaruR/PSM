<?php

include_once 'DAO_Citas.php';
include_once 'DB_Conection.php';

class ObtenerCitas extends DB
{
    public function _ObtenerCitas()
    {

        $idUser = $_POST['idUsuario'];
        $doctores = new Citas();

        $db = new DB();
        $pdo = $db->connect();

        if ($pdo) {
            try {
                $result = $doctores->ObtenerCitas($pdo, $idUser);

                if ($result) {
                    return $result;
                } else {
                    return [];
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        } else {
            return "Error: No se pudo conectar a la base de datos.";
        }
    }
}

$obtenerCitas = new ObtenerCitas();
$result = $obtenerCitas->_ObtenerCitas();

if (is_array($result)) {
    echo json_encode($result);
} else {
    echo $result;
}

?>