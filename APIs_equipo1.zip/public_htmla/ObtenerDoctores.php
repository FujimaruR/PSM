<?php

include_once 'DAO_Doctores.php';
include_once 'DB_Conection.php';

class ObtenerDoctores extends DB
{
    public function ObtenerListadoDoctores()
    {
        $doctores = new Doctores();

        $db = new DB();
        $pdo = $db->connect();

        if ($pdo) {
            try {
                $result = $doctores->ObtenerDoctores($pdo);

                if ($result) {
                    return $result;
                } else {
                    return [];
                }
            } catch (PDOException $e) {
                return "Error: " . $e->getMessage();
            }
        } else {
            return "Error: No se pudo conectar a la base de datos.";
        }
    }
}

$obtenerDoctores = new ObtenerDoctores();
$result = $obtenerDoctores->ObtenerListadoDoctores();

if (is_array($result)) {
    echo json_encode($result);
} else {
    echo $result;
}

?>