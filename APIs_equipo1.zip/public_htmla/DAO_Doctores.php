<?php


include 'DB_Conection.php';


class Doctores extends DB
{
   
    public function Registro($pdo, $nombre, $activo)
    {
        try {
            $sql = "INSERT INTO tb_Doctores (nombre, activo) 
                    VALUES (:nombre, :activo)";
            $stmt = $pdo->prepare($sql);

          
            $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
            $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);
        
    
            $pdo = null;
            
            if($stmt->execute()){
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    public function ActualizarDoctor($pdo, $nombre, $activo, $idDoctor)
    {
        try {
            $sql = "UPDATE tb_Doctores SET nombre = :nombre, activo = :activo WHERE idDoctor = :idDoctor";
            $stmt = $pdo->prepare($sql);

          
            $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
            $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);
            $stmt->bindParam(':idDoctor', $idDoctor, PDO::PARAM_INT);
        
    
            $pdo = null;
            
            if($stmt->execute()){
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    public function EliminarDoctor($pdo, $idDoctor)
    {
        try {
            $sql = "UPDATE tb_Doctores SET activo = :activo WHERE idDoctor = :idDoctor";
            $stmt = $pdo->prepare($sql);
            
            $activo = 0;

          
            $stmt->bindParam(':idDoctor', $idDoctor, PDO::PARAM_INT);
            $stmt->bindParam(':activo', $activo, PDO::PARAM_INT);
        
    
            $pdo = null;
            
            if($stmt->execute()){
                return true;
            } else {
                return false;
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }
    


    public function ObtenerDoctores($pdo)
    {
        try {
            $sql = "SELECT idDoctor , nombre 
                    FROM tb_Doctores WHERE activo = 1";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
        
            $doctores = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
            if ($doctores) {
                return $doctores;
            } else {
                echo "Error";
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }


}

?>