<?php


include 'DB_Conection.php';
class Mascotas extends DB
{

   public function Registro($pdo, $nombre, $edad, $raza, $activo, $idEspecie, $idUsuario, $imagen, $imagen2, $imagen3)
{
    try {
        $sql = "INSERT INTO tb_Mascotas (nombre, edad, raza, activo, idEspecie, idUsuario) 
                VALUES (:p_nombre, :p_edad, :p_raza, :p_activo, :p_idEspecie, :p_idUsuario)";
        $stmt = $pdo->prepare($sql);

        $stmt->bindParam(':p_nombre', $nombre, PDO::PARAM_STR);
        $stmt->bindParam(':p_edad', $edad, PDO::PARAM_INT);
        $stmt->bindParam(':p_raza', $raza, PDO::PARAM_STR);
        $stmt->bindParam(':p_activo', $activo, PDO::PARAM_INT);
        $stmt->bindParam(':p_idEspecie', $idEspecie, PDO::PARAM_INT);
        $stmt->bindParam(':p_idUsuario', $idUsuario, PDO::PARAM_INT);

        if ($stmt->execute()) {
            $lastInsertId = $pdo->lastInsertId();
            
            $imagenes = [$imagen, $imagen2, $imagen3];
            
           foreach ($imagenes as $key => $imagen) {
               
                $sqld = "INSERT INTO tb_Imagenes_Mascota (idMascota, activo, imagen) 
                        VALUES (:p_idMascota, :p_activod, :p_imagen)";
                $stmtt = $pdo->prepare($sqld);
    
                $stmtt->bindParam(':p_idMascota', $lastInsertId, PDO::PARAM_INT);
                $stmtt->bindParam(':p_activod', $activo, PDO::PARAM_INT);
                $stmtt->bindParam(':p_imagen', $imagen, PDO::PARAM_LOB);
    
                if (!$stmtt->execute()) {
                    return false; // No se pudo insertar el registro en la tabla de imágenes
                }
            }

            return true;
        } else {
            return false; // No se pudo insertar el registro en la tabla de mascotas
        }
    } catch (PDOException $e) {
        return "Error: " . $e->getMessage();
    }
}


    public function ModificarMascota($pdo, $nombre, $edad, $raza, $idEspecie, $idMascota, $img1, $img2, $img3)
    {
        try {
            $sql = "UPDATE tb_Mascotas SET nombre = :nombre, edad = :edad, raza = :raza, idEspecie = :idEspecie WHERE idMascota = :idMascota";
            $stmt = $pdo->prepare($sql);
    
            $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR);
            $stmt->bindParam(':edad', $edad, PDO::PARAM_INT);
            $stmt->bindParam(':raza', $raza, PDO::PARAM_STR);
            $stmt->bindParam(':idEspecie', $idEspecie, PDO::PARAM_INT);
            $stmt->bindParam(':idMascota', $idMascota, PDO::PARAM_INT);
            
            if ($stmt->execute()) {
            
            $stmtci = $pdo->prepare("DELETE FROM tb_Imagenes_Mascota WHERE idMascota = :p_idMascota");
            $stmtci->bindParam(':p_idMascota', $idMascota);
            $stmtci->execute();
            
            $imagenes = [$img1, $img2, $img3];
            
            $activo = 1;
            
           foreach ($imagenes as $key => $imagen) {
               
                $sqld = "INSERT INTO tb_Imagenes_Mascota (idMascota, activo, imagen) 
                        VALUES (:p_idMascotad, :p_activod, :p_imagen)";
                $stmtt = $pdo->prepare($sqld);
    
                $stmtt->bindParam(':p_idMascotad', $idMascota, PDO::PARAM_INT);
                $stmtt->bindParam(':p_activod', $activo, PDO::PARAM_INT);
                $stmtt->bindParam(':p_imagen', $imagen, PDO::PARAM_LOB);
    
                if (!$stmtt->execute()) {
                    return false; // No se pudo insertar el registro en la tabla de imágenes
                }
            }
            return true;
        } else {
            return false; // No se pudo insertar el registro en la tabla de mascotas
        }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    function insertOfflinePosts($pdo, $nombre, $edad, $raza, $activo, $idEspecie, $idUsuario)
    {
        try {
            $sql = "INSERT INTO tb_Mascotas (nombre, edad, raza, activo, idEspecie, idUsuario) 
                    VALUES (:p_nombre, :p_edad, :p_raza, :p_activo, :p_idEspecie, :p_idUsuario)";
            $stmt = $pdo->prepare($sql);
    
            $stmt->bindParam(':p_nombre', $nombre, PDO::PARAM_STR);
            $stmt->bindParam(':p_edad', $edad, PDO::PARAM_INT);
            $stmt->bindParam(':p_raza', $raza, PDO::PARAM_STR);
            $stmt->bindParam(':p_activo', $activo, PDO::PARAM_INT);
            $stmt->bindParam(':p_idEspecie', $idEspecie, PDO::PARAM_INT);
            $stmt->bindParam(':p_idUsuario', $idUsuario, PDO::PARAM_INT);
    
            $result = $stmt->execute();
    
            $lastInsertId = $pdo->lastInsertId(); // Obtiene el ID del último registro insertado
    
            if ($result) {
                return $lastInsertId; // Devuelve el ID del último registro insertado
            } else {
                return false; // No se pudo insertar el registro
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }


    function InsertEspecie($especie)
    {
        try {

            $con = $this->connect();

            $sql = "INSERT INTO tb_Especies (nombre, activo) 
                    VALUES (:p_nombre, :activo)";

                    
            $stmt = $con->prepare($sql);

            $estatusSubida = 1;
    
            $stmt->bindParam(':p_nombre', $especie, PDO::PARAM_STR);
            $stmt->bindParam(':activo', $estatusSubida, PDO::PARAM_INT);
    
    
            $result = $stmt->execute();
    
            $pdo = null;
    
            if ($result) {
                return $result;
            } else {
                return $result;
            }
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    function ObtenEspecies()
    {
        try {

            $con = $this->connect();

            $sql =  "SELECT * FROM tb_Especies WHERE activo = 1";
                    
            $stmt = $con->prepare($sql);
    
            $stmt->execute();
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $con = null;
    
            return $result;
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }
    
    function ObtenMascotas($userIDSql) {
        try {

            $con = $this->connect();

            $sql =  "SELECT
    m.idMascota,
    m.nombre AS nombreMascota,
    m.edad,
    m.raza,
    m.activo AS activoMascota,
    e.idEspecie,
    e.nombre AS nombreEspecie,
    e.activo AS activoEspecie,
    m.idUsuario,
    im.idMascota AS idImagenesMascota,
    im.activo AS activoImagen,
    (SELECT im.imagen FROM tb_Imagenes_Mascota WHERE im.idMascota = m.idMascota LIMIT 1) AS imagen
FROM
    tb_Mascotas m
    INNER JOIN tb_Especies e ON m.idEspecie = e.idEspecie
    LEFT JOIN tb_Imagenes_Mascota im ON m.idMascota = im.idMascota
WHERE m.idUsuario = :idUser AND m.activo = 1
GROUP BY
    m.idMascota;
";
                    
            $stmt = $con->prepare($sql);
            $stmt->bindParam(':idUser', $userIDSql, PDO::PARAM_INT);
            $stmt->execute();
            if($stmt->rowCount() > 0){
                $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $con = null;
                return $result;
            } else {
                $con = null;
                return false;
            }
            
        } catch (PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    function EditarEspecie($nombre, $idEspecie)
{
    try {
        $con = $this->connect();
        
        // UPDATE query
        $sql = "UPDATE tb_Especies SET nombre = :nombre WHERE idEspecie = :idEspecie";

        // Prepare statement
        $stmt = $con->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':idEspecie', $idEspecie);

        // Execute the UPDATE statement
        $stmt->execute();

        // Check if any row is affected
        if ($stmt->rowCount() > 0) {
            $res = "Especie actualizada correctamente.";
        } else {
            $res = "No se ha podido actualizar la especie. Por favor, comprueba si el id de especie es correcto y vuelve a intentarlo.";
        }

        $con = null;
        return $res;

    } catch (PDOException $e) {
        return "Error: " . $e->getMessage();
    }
}


function EliminarEspecie($idEspecie)
{
    try {
        $con = $this->connect();
        
        // UPDATE query
        $sql = "UPDATE tb_Especies SET activo = :activo WHERE idEspecie = :idEspecie";

        // Prepare statement
        $stmt = $con->prepare($sql);

        $activo = false;
        // Bind parameters
        $stmt->bindParam(':activo', $activo);
        $stmt->bindParam(':idEspecie', $idEspecie);

        // Execute the UPDATE statement
        $stmt->execute();

        // Check if any row is affected
        if ($stmt->rowCount() > 0) {
            $res = "Especie eliminada correctamente.";
        } else {
            $res = "No se ha podido eliminar la especie. Por favor, comprueba si el id de especie es correcto y vuelve a intentarlo.";
        }

        $con = null;
        return $res;

    } catch (PDOException $e) {
        return "Error: " . $e->getMessage();
    }
}

function DeleteMascota($con, $idMascota){
    try {
        
        // UPDATE query
        $sql = "UPDATE tb_Mascotas SET activo = :activo WHERE idMascota = :idMascota";

        // Prepare statement
        $stmt = $con->prepare($sql);

        $activo = false;
        // Bind parameters
        $stmt->bindParam(':activo', $activo);
        $stmt->bindParam(':idMascota', $idMascota);

        // Execute the UPDATE statement
        $stmt->execute();

        // Check if any row is affected
        if ($stmt->rowCount() > 0) {
            $res = true;
        } else {
            $res = false;
        }

        $con = null;
        return $res;

    } catch (PDOException $e) {
        return "Error: " . $e->getMessage();
    }
}



}

?>